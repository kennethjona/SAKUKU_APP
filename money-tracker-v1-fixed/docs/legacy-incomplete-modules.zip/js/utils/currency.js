/** Currency formatting. Amounts are integer rupiah; no fractional values are ever displayed. */
const IDR = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  maximumFractionDigits: 0,
});

export function formatIDR(amount) {
  const value = Number.isFinite(amount) ? amount : 0;
  return IDR.format(value);
}

export function formatSignedIDR(amount, type) {
  return `${type === "income" ? "+" : "−"}${formatIDR(amount)}`;
}

/** Compact label for chart axes, e.g. 1,2 jt. */
export function formatCompactIDR(amount) {
  const value = Number.isFinite(amount) ? Math.abs(amount) : 0;
  const sign = amount < 0 ? "−" : "";
  if (value >= 1_000_000_000) return `${sign}${trim(value / 1_000_000_000)} M`;
  if (value >= 1_000_000) return `${sign}${trim(value / 1_000_000)} jt`;
  if (value >= 1_000) return `${sign}${trim(value / 1_000)} rb`;
  return `${sign}${value}`;
}

function trim(value) {
  return Number(value.toFixed(1)).toLocaleString("id-ID");
}

export function formatPercent(value, digits = 0) {
  if (!Number.isFinite(value)) return "—";
  return `${value.toLocaleString("id-ID", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })}%`;
}
