/**
 * Calendar-date helpers.
 * Transaction dates are local calendar dates in YYYY-MM-DD form. They are never
 * parsed as UTC, so a transaction never shifts to the previous/next day.
 */

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;
const pad = (value) => String(value).padStart(2, "0");

export function toISODate(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayISO(now = new Date()) {
  return toISODate(now);
}

export function nowISOString() {
  return new Date().toISOString();
}

export function monthOf(dateString) {
  return String(dateString).slice(0, 7);
}

export function currentMonth(now = new Date()) {
  return monthOf(toISODate(now));
}

export function isValidDateString(value) {
  if (typeof value !== "string" || !DATE_RE.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  if (year < 1900 || year > 9999) return false;
  const date = new Date(year, month - 1, day);
  return (
    date.getFullYear() === year &&
    date.getMonth() === month - 1 &&
    date.getDate() === day
  );
}

export function isValidMonthString(value) {
  return typeof value === "string" && MONTH_RE.test(value);
}

/** Builds a local Date at midnight; safe for formatting without a UTC shift. */
export function parseDateLocal(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  return new Date(year, month - 1, day);
}

export function parseMonthLocal(monthString) {
  return parseDateLocal(`${monthString}-01`);
}

export function formatDateID(dateString, options = {}) {
  const fallback = options.fallback ?? "—";
  if (!isValidDateString(dateString)) return fallback;
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    ...options,
  }).format(parseDateLocal(dateString));
}

export function formatDateLongID(dateString) {
  if (!isValidDateString(dateString)) return "—";
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(parseDateLocal(dateString));
}

export function formatDateTimeID(isoString) {
  if (!isoString) return "—";
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function formatMonthID(monthString) {
  if (!isValidMonthString(monthString)) return "—";
  return new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric" }).format(
    parseMonthLocal(monthString),
  );
}

export function formatMonthShortID(monthString) {
  if (!isValidMonthString(monthString)) return "—";
  return new Intl.DateTimeFormat("id-ID", { month: "short", year: "2-digit" }).format(
    parseMonthLocal(monthString),
  );
}

export function daysInMonth(monthString) {
  if (!isValidMonthString(monthString)) return 0;
  const year = Number(monthString.slice(0, 4));
  const month = Number(monthString.slice(5, 7));
  return new Date(year, month, 0).getDate();
}

export function addMonths(monthString, delta) {
  if (!isValidMonthString(monthString)) return monthString;
  const year = Number(monthString.slice(0, 4));
  const month = Number(monthString.slice(5, 7)) - 1 + delta;
  return monthOf(toISODate(new Date(year, month, 1)));
}

export function previousMonth(monthString) {
  return addMonths(monthString, -1);
}

export function monthRange(endMonth, count) {
  const months = [];
  for (let index = count - 1; index >= 0; index -= 1) {
    months.push(addMonths(endMonth, -index));
  }
  return months;
}

/**
 * Number of days used for "average daily spending".
 * Past months use the full calendar length; the current month uses elapsed days
 * (including today); future months use 0, so no meaninglessly small average is shown.
 */
export function elapsedDays(monthString, today = todayISO()) {
  if (!isValidMonthString(monthString)) return 0;
  const current = monthOf(today);
  if (monthString > current) return 0;
  if (monthString === current) return Math.max(1, Number(today.slice(8, 10)));
  return daysInMonth(monthString);
}

export function firstDayOfMonth(monthString) {
  return `${monthString}-01`;
}
