/**
 * Pure financial calculations. No DOM, no storage, no floating-point currency math:
 * every amount stored and summed here is an integer number of rupiah.
 */
import { daysInMonth, elapsedDays, monthOf, previousMonth, todayISO } from "./dates.js";

export function isIncome(transaction) {
  return transaction?.type === "income";
}

export function isExpense(transaction) {
  return transaction?.type === "expense";
}

export function sumAmounts(transactions, type) {
  return transactions
    .filter((transaction) => transaction.type === type)
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function totals(transactions) {
  const income = sumAmounts(transactions, "income");
  const expense = sumAmounts(transactions, "expense");
  return { income, expense, balance: income - expense };
}

/** Opening balance is starting money, never income. */
export function availableBalance(transactions, openingBalance) {
  return Number(openingBalance) + totals(transactions).balance;
}

export function inMonth(transactions, month) {
  return transactions.filter((transaction) => transaction.date.slice(0, 7) === month);
}

export function monthlyTotals(transactions, month) {
  return totals(inMonth(transactions, month));
}

export function monthlyExpenseTotal(transactions, month) {
  return monthlyTotals(transactions, month).expense;
}

/** Category spending/income totals for one month, largest first. */
export function categoryTotals(transactions, month, type = "expense") {
  const buckets = new Map();
  for (const transaction of transactions) {
    if (transaction.type !== type) continue;
    if (transaction.date.slice(0, 7) !== month) continue;
    buckets.set(transaction.categoryId, (buckets.get(transaction.categoryId) ?? 0) + transaction.amount);
  }
  return [...buckets.entries()]
    .map(([categoryId, amount]) => ({ categoryId, amount }))
    .sort((a, b) => b.amount - a.amount);
}

/**
 * Budget usage without the common "cap at 100%" bug: percent keeps growing
 * above 100 and `state` distinguishes warning (>=75), critical (exactly 100)
 * and over (>100).
 */
export function budgetStatus(limitAmount, spentAmount) {
  const limit = Number.isSafeInteger(limitAmount) && limitAmount > 0 ? limitAmount : 0;
  const spent = Number.isSafeInteger(spentAmount) && spentAmount > 0 ? spentAmount : 0;

  if (limit === 0) {
    return {
      configured: false,
      limit: 0,
      spent,
      remaining: null,
      percent: null,
      state: "none",
    };
  }

  const percent = (spent / limit) * 100;
  let state = "safe";
  if (spent > limit) state = "over";
  else if (percent >= 100) state = "critical";
  else if (percent >= 75) state = "warning";

  return {
    configured: true,
    limit,
    spent,
    remaining: limit - spent,
    percent,
    state,
  };
}

export function outingSpending(transactions, outingId) {
  return transactions
    .filter((transaction) => transaction.type === "expense" && transaction.outingId === outingId)
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function outingStatus(outing, transactions) {
  const spent = outingSpending(transactions, outing.id);
  return { ...budgetStatus(outing.plannedBudget, spent), spent };
}

/**
 * Average daily spending. The day count is explicit and consistent:
 * elapsed days for the current month, all calendar days for a past month,
 * zero for a future month. Rounded to whole rupiah for display.
 */
export function averageDailySpending(transactions, month, today = todayISO()) {
  const total = monthlyExpenseTotal(transactions, month);
  const days = elapsedDays(month, today);
  return {
    total,
    days,
    average: days > 0 ? Math.round(total / days) : 0,
    isFuture: month > monthOf(today),
  };
}

export function dailyExpenseSeries(transactions, month) {
  const count = daysInMonth(month);
  const buckets = new Array(count).fill(0);
  for (const transaction of transactions) {
    if (transaction.type !== "expense" || transaction.date.slice(0, 7) !== month) continue;
    const day = Number(transaction.date.slice(8, 10));
    if (day >= 1 && day <= count) buckets[day - 1] += transaction.amount;
  }
  return buckets.map((amount, index) => ({
    date: `${month}-${String(index + 1).padStart(2, "0")}`,
    day: index + 1,
    amount,
  }));
}

export function monthlyFlowSeries(transactions, months) {
  return months.map((month) => ({ month, ...monthlyTotals(transactions, month) }));
}

export function highestCategory(transactions, month) {
  return categoryTotals(transactions, month, "expense")[0] ?? null;
}

export function percentChange(current, previous) {
  if (!Number.isFinite(current) || !Number.isFinite(previous) || previous <= 0) return null;
  return ((current - previous) / previous) * 100;
}

export function compareMonths(transactions, month) {
  const current = monthlyTotals(transactions, month);
  const previous = monthlyTotals(transactions, previousMonth(month));
  return {
    current,
    previous,
    expenseChangePercent: percentChange(current.expense, previous.expense),
    incomeChangePercent: percentChange(current.income, previous.income),
    netChange: current.balance - previous.balance,
  };
}

/**
 * Removing an outing must not delete financial history, so linked transactions
 * are detached instead. Pure helper used by the outing service and tests.
 */
export function detachOutingTransactions(transactions, outingId, updatedAt) {
  return transactions.map((transaction) =>
    transaction.outingId === outingId
      ? { ...transaction, outingId: null, updatedAt }
      : transaction,
  );
}
