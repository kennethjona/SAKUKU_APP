/** Boundary validation for every value that reaches storage. */
import {
  AMOUNT_LIMIT,
  CATEGORY_NAME_MAX,
  DESCRIPTION_MAX,
  NAME_MAX,
  NOTE_MAX,
  OUTING_NAME_MAX,
  OUTING_STATUS,
  PALETTE,
  THEMES,
  TX_TYPES,
} from "./defaults.js";
import { formatDateID, isValidDateString, isValidMonthString, todayISO } from "./dates.js";

const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

/** Accepts "Rp 1.000", "1.000" or "1000". Rejects decimals and malformed separators. */
export function parseAmountInput(raw, { allowZero = false } = {}) {
  if (typeof raw === "number") {
    if (!Number.isSafeInteger(raw) || raw < 0 || raw > AMOUNT_LIMIT) return null;
    if (!allowZero && raw === 0) return null;
    return raw;
  }
  const text = String(raw ?? "")
    .trim()
    .replace(/^Rp\.?\s*/i, "");
  if (!text) return null;
  if (!/^(?:\d+|\d{1,3}(?:\.\d{3})+)$/.test(text)) return null;
  const value = Number(text.replace(/\./g, ""));
  if (!Number.isSafeInteger(value) || value > AMOUNT_LIMIT) return null;
  if (!allowZero && value === 0) return null;
  return value;
}

function textLengthError(text, max) {
  if (text.length > max) return `Maksimal ${max} karakter.`;
  return null;
}

export function validateTransaction(input, context = {}) {
  const errors = {};
  const categories = context.categories ?? [];
  const outings = context.outings ?? [];
  const settings = context.settings ?? {};
  const existing = context.existing ?? null;
  const today = context.today ?? todayISO();

  const name = String(input?.name ?? "").trim();
  if (!name) errors.name = "Nama transaksi wajib diisi.";
  else if (name.length > NAME_MAX) errors.name = `Nama transaksi maksimal ${NAME_MAX} karakter.`;

  const amount = parseAmountInput(input?.amount);
  if (amount === null) {
    errors.amount = "Masukkan nominal rupiah bulat lebih dari 0, tanpa desimal.";
  }

  const type = input?.type;
  if (!TX_TYPES.includes(type)) errors.type = "Jenis transaksi tidak dikenal.";

  const categoryId = String(input?.categoryId ?? "");
  const category = categories.find((item) => item.id === categoryId);
  if (!categoryId) errors.categoryId = "Pilih kategori.";
  else if (!category) errors.categoryId = "Kategori tidak ditemukan.";
  else if (category.type !== type) errors.categoryId = "Kategori tidak sesuai dengan jenis transaksi.";
  else if (category.archived && existing?.categoryId !== categoryId) {
    errors.categoryId = "Kategori yang diarsipkan tidak dapat dipakai untuk transaksi baru.";
  }

  const date = String(input?.date ?? "");
  if (!date) errors.date = "Tanggal wajib diisi.";
  else if (!isValidDateString(date)) errors.date = "Tanggal tidak valid.";
  else if (date > today) errors.date = "Tanggal tidak boleh di masa depan.";
  else if (settings.trackingStartDate && date < settings.trackingStartDate) {
    errors.date = `Tanggal tidak boleh sebelum mulai pencatatan (${formatDateID(settings.trackingStartDate)}).`;
  }

  const description = String(input?.description ?? "").trim();
  const descriptionError = textLengthError(description, DESCRIPTION_MAX);
  if (descriptionError) errors.description = `Deskripsi ${descriptionError.toLowerCase()}`;

  let outingId = input?.outingId ? String(input.outingId) : null;
  if (outingId === "") outingId = null;
  if (outingId && !outings.some((outing) => outing.id === outingId)) {
    errors.outingId = "Aktivitas tidak ditemukan.";
  }

  const ok = Object.keys(errors).length === 0;
  return {
    ok,
    errors,
    value: ok
      ? {
          name,
          amount,
          type,
          categoryId,
          date,
          description,
          outingId,
        }
      : null,
  };
}

export function validateCategory(input, context = {}) {
  const errors = {};
  const categories = context.categories ?? [];
  const existing = context.existing ?? null;

  const name = String(input?.name ?? "").trim();
  if (!name) errors.name = "Nama kategori wajib diisi.";
  else if (name.length > CATEGORY_NAME_MAX) {
    errors.name = `Nama kategori maksimal ${CATEGORY_NAME_MAX} karakter.`;
  }

  const type = input?.type;
  if (!TX_TYPES.includes(type)) errors.type = "Tipe kategori tidak dikenal.";

  let color = String(input?.color ?? "").trim();
  if (!color) color = PALETTE[categories.length % PALETTE.length];
  if (!COLOR_RE.test(color)) errors.color = "Warna kategori tidak valid.";

  if (name && TX_TYPES.includes(type)) {
    const duplicate = categories.some(
      (item) =>
        item.id !== existing?.id &&
        item.type === type &&
        item.name.toLowerCase() === name.toLowerCase(),
    );
    if (duplicate) errors.name = "Kategori dengan nama ini sudah ada untuk tipe yang sama.";
  }

  const ok = Object.keys(errors).length === 0;
  return {
    ok,
    errors,
    value: ok
      ? {
          name,
          type,
          color,
          archived: Boolean(input?.archived),
        }
      : null,
  };
}

export function validateBudget(input, context = {}) {
  const errors = {};
  const categories = context.categories ?? [];

  const month = String(input?.month ?? "");
  if (!isValidMonthString(month)) errors.month = "Bulan anggaran tidak valid.";

  const rawCategoryId = input?.categoryId;
  const categoryId = rawCategoryId ? String(rawCategoryId) : null;
  if (categoryId) {
    const category = categories.find((item) => item.id === categoryId);
    if (!category) errors.categoryId = "Kategori tidak ditemukan.";
    else if (category.type !== "expense") {
      errors.categoryId = "Anggaran kategori hanya untuk kategori pengeluaran.";
    }
  }

  const limitAmount = parseAmountInput(input?.limitAmount);
  if (limitAmount === null) {
    errors.limitAmount = "Masukkan batas anggaran rupiah bulat lebih dari 0.";
  }

  const ok = Object.keys(errors).length === 0;
  return {
    ok,
    errors,
    value: ok ? { month, categoryId, limitAmount } : null,
  };
}

export function validateOuting(input, context = {}) {
  const errors = {};
  const today = context.today ?? todayISO();

  const name = String(input?.name ?? "").trim();
  if (!name) errors.name = "Nama aktivitas wajib diisi.";
  else if (name.length > OUTING_NAME_MAX) {
    errors.name = `Nama aktivitas maksimal ${OUTING_NAME_MAX} karakter.`;
  }

  const date = String(input?.date ?? "");
  if (!date) errors.date = "Tanggal aktivitas wajib diisi.";
  else if (!isValidDateString(date)) errors.date = "Tanggal aktivitas tidak valid.";
  else if (date > today && context.allowFuture === false) {
    errors.date = "Tanggal aktivitas tidak boleh di masa depan.";
  }

  const plannedBudget = parseAmountInput(input?.plannedBudget, { allowZero: true });
  if (plannedBudget === null) {
    errors.plannedBudget = "Masukkan anggaran aktivitas berupa rupiah bulat (boleh 0).";
  }

  const note = String(input?.note ?? "").trim();
  const noteError = textLengthError(note, NOTE_MAX);
  if (noteError) errors.note = `Catatan ${noteError.toLowerCase()}`;

  const status = input?.status ?? "active";
  if (!OUTING_STATUS.includes(status)) errors.status = "Status aktivitas tidak dikenal.";

  const ok = Object.keys(errors).length === 0;
  return {
    ok,
    errors,
    value: ok
      ? {
          name,
          date,
          plannedBudget,
          note,
          status,
        }
      : null,
  };
}

export function validateSettings(input, context = {}) {
  const errors = {};
  const transactions = context.transactions ?? [];
  const today = context.today ?? todayISO();

  const openingBalance = parseAmountInput(input?.openingBalance, { allowZero: true });
  if (openingBalance === null) {
    errors.openingBalance = "Saldo awal harus rupiah bulat 0 atau lebih, tanpa desimal.";
  }

  const trackingStartDate = String(input?.trackingStartDate ?? "");
  if (!trackingStartDate) errors.trackingStartDate = "Tanggal mulai pencatatan wajib diisi.";
  else if (!isValidDateString(trackingStartDate)) errors.trackingStartDate = "Tanggal mulai tidak valid.";
  else if (trackingStartDate > today) {
    errors.trackingStartDate = "Tanggal mulai tidak boleh di masa depan.";
  } else if (transactions.length > 0) {
    const earliest = transactions
      .map((transaction) => transaction.date)
      .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))[0];
    if (trackingStartDate > earliest) {
      errors.trackingStartDate = `Tanggal mulai tidak boleh setelah transaksi paling awal (${formatDateID(earliest)}).`;
    }
  }

  const theme = input?.theme;
  if (!THEMES.includes(theme)) errors.theme = "Tema tidak dikenal.";

  const ok = Object.keys(errors).length === 0;
  return {
    ok,
    errors,
    value: ok
      ? {
          openingBalance,
          trackingStartDate,
          theme,
          legacyMigratedAt: input?.legacyMigratedAt ?? null,
        }
      : null,
  };
}
