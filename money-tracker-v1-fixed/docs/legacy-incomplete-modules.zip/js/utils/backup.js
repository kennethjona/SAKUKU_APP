/**
 * JSON backup shape and validation. Pure: nothing here touches storage, so an
 * invalid file can be rejected before the database is modified.
 */
import {
  AMOUNT_LIMIT,
  CATEGORY_NAME_MAX,
  DESCRIPTION_MAX,
  NAME_MAX,
  NOTE_MAX,
  OUTING_NAME_MAX,
  OUTING_STATUS,
  SCHEMA_VERSION,
  THEMES,
  TX_TYPES,
} from "./defaults.js";
import { isValidDateString, isValidMonthString, todayISO } from "./dates.js";

const MAX_RECORDS = 100_000;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isTimestamp(value) {
  return typeof value === "string" && value.length > 0 && !Number.isNaN(Date.parse(value));
}

function isSafeAmount(value, { allowZero = false } = {}) {
  return (
    Number.isSafeInteger(value) &&
    value <= AMOUNT_LIMIT &&
    (allowZero ? value >= 0 : value > 0)
  );
}

function text(value, max) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}

function optionalText(value, max) {
  return typeof value === "string" && value.length <= max;
}

export function buildBackup(state, now = new Date()) {
  return {
    app: "money-tracker-v1",
    schemaVersion: SCHEMA_VERSION,
    exportedAt: now.toISOString(),
    data: {
      settings: {
        openingBalance: state.settings.openingBalance,
        trackingStartDate: state.settings.trackingStartDate,
        theme: state.settings.theme,
        legacyMigratedAt: state.settings.legacyMigratedAt ?? null,
      },
      categories: state.categories.map((category) => ({
        id: category.id,
        name: category.name,
        type: category.type,
        color: category.color,
        archived: category.archived,
        createdAt: category.createdAt,
        updatedAt: category.updatedAt,
      })),
      transactions: state.transactions.map((transaction) => ({
        id: transaction.id,
        name: transaction.name,
        amount: transaction.amount,
        type: transaction.type,
        categoryId: transaction.categoryId,
        date: transaction.date,
        description: transaction.description ?? "",
        outingId: transaction.outingId ?? null,
        createdAt: transaction.createdAt,
        updatedAt: transaction.updatedAt,
      })),
      budgets: state.budgets.map((budget) => ({
        id: budget.id,
        month: budget.month,
        categoryId: budget.categoryId ?? null,
        limitAmount: budget.limitAmount,
      })),
      outings: state.outings.map((outing) => ({
        id: outing.id,
        name: outing.name,
        date: outing.date,
        plannedBudget: outing.plannedBudget,
        note: outing.note ?? "",
        status: outing.status,
        createdAt: outing.createdAt,
        updatedAt: outing.updatedAt,
      })),
    },
  };
}

export function serializeBackup(state, now = new Date()) {
  return JSON.stringify(buildBackup(state, now), null, 2);
}

/**
 * Validates an entire backup before a restore. Returns normalized data with
 * canonical budget ids. Any error means the caller must leave storage untouched.
 */
export function validateBackup(raw, options = {}) {
  const errors = [];
  let parsed = raw;

  if (typeof raw === "string") {
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { ok: false, errors: ["Berkas bukan JSON yang valid."], data: null };
    }
  }

  if (!isObject(parsed)) {
    return { ok: false, errors: ["Struktur cadangan tidak valid."], data: null };
  }

  if (parsed.app !== undefined && parsed.app !== "money-tracker-v1") {
    errors.push("Berkas bukan cadangan Money Tracker V1.");
  }

  if (parsed.schemaVersion !== SCHEMA_VERSION) {
    errors.push(
      `Versi cadangan tidak didukung (ditemukan: ${String(parsed.schemaVersion)}, didukung: ${SCHEMA_VERSION}).`,
    );
  }

  const data = parsed.data;
  if (!isObject(data)) {
    return { ok: false, errors: [...errors, "Bagian data cadangan tidak ditemukan."], data: null };
  }

  for (const key of ["categories", "transactions", "budgets", "outings"]) {
    if (!Array.isArray(data[key])) errors.push(`Daftar ${key} tidak ditemukan.`);
    else if (data[key].length > MAX_RECORDS) errors.push(`Daftar ${key} terlalu besar.`);
  }
  if (!isObject(data.settings)) errors.push("Pengaturan keuangan tidak ditemukan.");
  if (errors.length > 0) return { ok: false, errors, data: null };

  const settings = data.settings;
  const today = options.today ?? todayISO();
  const normalizedSettings = {
    openingBalance: settings.openingBalance,
    trackingStartDate: settings.trackingStartDate,
    theme: settings.theme,
    legacyMigratedAt: settings.legacyMigratedAt ?? null,
  };

  if (!isSafeAmount(settings.openingBalance, { allowZero: true })) {
    errors.push("Saldo awal tidak valid.");
  }
  if (!isValidDateString(settings.trackingStartDate)) {
    errors.push("Tanggal mulai pencatatan tidak valid.");
  } else if (settings.trackingStartDate > today) {
    errors.push("Tanggal mulai pencatatan berada di masa depan.");
  }
  if (!THEMES.includes(settings.theme)) errors.push("Tema pada cadangan tidak dikenal.");
  if (normalizedSettings.legacyMigratedAt !== null && !isTimestamp(normalizedSettings.legacyMigratedAt)) {
    errors.push("Penanda migrasi pada cadangan tidak valid.");
  }

  const categoryIds = new Set();
  const categories = [];
  data.categories.forEach((category, index) => {
    const label = `Kategori #${index + 1}`;
    if (!isObject(category)) return errors.push(`${label}: data tidak valid.`);
    if (typeof category.id !== "string" || !category.id.trim()) {
      errors.push(`${label}: ID tidak valid.`);
    } else if (categoryIds.has(category.id)) {
      errors.push(`${label}: ID duplikat.`);
    } else {
      categoryIds.add(category.id);
    }
    if (!text(category.name, CATEGORY_NAME_MAX)) errors.push(`${label}: nama tidak valid.`);
    if (!TX_TYPES.includes(category.type)) errors.push(`${label}: tipe tidak valid.`);
    if (typeof category.color !== "string" || !COLOR_RE.test(category.color)) {
      errors.push(`${label}: warna tidak valid.`);
    }
    if (typeof category.archived !== "boolean") errors.push(`${label}: status arsip tidak valid.`);
    if (!isTimestamp(category.createdAt)) errors.push(`${label}: waktu dibuat tidak valid.`);
    if (!isTimestamp(category.updatedAt)) errors.push(`${label}: waktu diubah tidak valid.`);
    categories.push({
      id: category.id,
      name: category.name,
      type: category.type,
      color: category.color,
      archived: Boolean(category.archived),
      createdAt: category.createdAt,
      updatedAt: category.updatedAt,
    });
  });

  const outingIds = new Set();
  const outings = [];
  data.outings.forEach((outing, index) => {
    const label = `Aktivitas #${index + 1}`;
    if (!isObject(outing)) return errors.push(`${label}: data tidak valid.`);
    if (typeof outing.id !== "string" || !outing.id.trim()) {
      errors.push(`${label}: ID tidak valid.`);
    } else if (outingIds.has(outing.id)) {
      errors.push(`${label}: ID duplikat.`);
    } else {
      outingIds.add(outing.id);
    }
    if (!text(outing.name, OUTING_NAME_MAX)) errors.push(`${label}: nama tidak valid.`);
    if (!isValidDateString(outing.date)) errors.push(`${label}: tanggal tidak valid.`);
    if (!isSafeAmount(outing.plannedBudget, { allowZero: true })) {
      errors.push(`${label}: anggaran tidak valid.`);
    }
    if (!optionalText(outing.note ?? "", NOTE_MAX)) errors.push(`${label}: catatan terlalu panjang.`);
    if (!OUTING_STATUS.includes(outing.status)) errors.push(`${label}: status tidak valid.`);
    if (!isTimestamp(outing.createdAt)) errors.push(`${label}: waktu dibuat tidak valid.`);
    if (!isTimestamp(outing.updatedAt)) errors.push(`${label}: waktu diubah tidak valid.`);
    outings.push({
      id: outing.id,
      name: outing.name,
      date: outing.date,
      plannedBudget: outing.plannedBudget,
      note: outing.note ?? "",
      status: outing.status,
      createdAt: outing.createdAt,
      updatedAt: outing.updatedAt,
    });
  });

  const categoryById = new Map(categories.map((category) => [category.id, category]));
  const transactionIds = new Set();
  const transactions = [];
  data.transactions.forEach((transaction, index) => {
    const label = `Transaksi #${index + 1}`;
    if (!isObject(transaction)) return errors.push(`${label}: data tidak valid.`);
    if (typeof transaction.id !== "string" || !transaction.id.trim()) {
      errors.push(`${label}: ID tidak valid.`);
    } else if (transactionIds.has(transaction.id)) {
      errors.push(`${label}: ID duplikat.`);
    } else {
      transactionIds.add(transaction.id);
    }
    if (!text(transaction.name, NAME_MAX)) errors.push(`${label}: nama tidak valid.`);
    if (!isSafeAmount(transaction.amount)) errors.push(`${label}: nominal tidak valid.`);
    if (!TX_TYPES.includes(transaction.type)) errors.push(`${label}: jenis tidak valid.`);

    const category = categoryById.get(transaction.categoryId);
    if (!category) errors.push(`${label}: kategori tidak ditemukan.`);
    else if (category.type !== transaction.type) {
      errors.push(`${label}: kategori tidak sesuai jenis transaksi.`);
    }

    if (!isValidDateString(transaction.date)) {
      errors.push(`${label}: tanggal tidak valid.`);
    } else {
      if (transaction.date > today) errors.push(`${label}: tanggal di masa depan.`);
      if (
        isValidDateString(settings.trackingStartDate) &&
        transaction.date < settings.trackingStartDate
      ) {
        errors.push(`${label}: tanggal sebelum mulai pencatatan.`);
      }
    }

    if (!optionalText(transaction.description ?? "", DESCRIPTION_MAX)) {
      errors.push(`${label}: deskripsi terlalu panjang.`);
    }
    const outingId = transaction.outingId ?? null;
    if (outingId !== null && !outingIds.has(outingId)) {
      errors.push(`${label}: aktivitas tidak ditemukan.`);
    }
    if (!isTimestamp(transaction.createdAt)) errors.push(`${label}: waktu dibuat tidak valid.`);
    if (!isTimestamp(transaction.updatedAt)) errors.push(`${label}: waktu diubah tidak valid.`);

    transactions.push({
      id: transaction.id,
      name: transaction.name,
      amount: transaction.amount,
      type: transaction.type,
      categoryId: transaction.categoryId,
      date: transaction.date,
      description: transaction.description ?? "",
      outingId,
      createdAt: transaction.createdAt,
      updatedAt: transaction.updatedAt,
    });
  });

  const budgetKeys = new Set();
  const budgets = [];
  data.budgets.forEach((budget, index) => {
    const label = `Anggaran #${index + 1}`;
    if (!isObject(budget)) return errors.push(`${label}: data tidak valid.`);
    if (!isValidMonthString(budget.month)) errors.push(`${label}: bulan tidak valid.`);

    const categoryId = budget.categoryId ?? null;
    if (categoryId !== null) {
      const category = categoryById.get(categoryId);
      if (!category) errors.push(`${label}: kategori tidak ditemukan.`);
      else if (category.type !== "expense") {
        errors.push(`${label}: anggaran hanya untuk kategori pengeluaran.`);
      }
    }

    if (!isSafeAmount(budget.limitAmount)) errors.push(`${label}: batas anggaran tidak valid.`);

    const key = `${budget.month}:${categoryId ?? "overall"}`;
    if (budgetKeys.has(key)) errors.push(`${label}: anggaran duplikat untuk bulan dan kategori yang sama.`);
    budgetKeys.add(key);

    budgets.push({
      id: key,
      month: budget.month,
      categoryId,
      limitAmount: budget.limitAmount,
    });
  });

  if (errors.length > 0) {
    return { ok: false, errors: [...new Set(errors)], data: null };
  }

  return {
    ok: true,
    errors: [],
    data: {
      settings: {
        openingBalance: normalizedSettings.openingBalance,
        trackingStartDate: normalizedSettings.trackingStartDate,
        theme: normalizedSettings.theme,
        legacyMigratedAt: normalizedSettings.legacyMigratedAt,
      },
      categories,
      transactions,
      budgets,
      outings,
    },
  };
}
