export function renderSettingsForm(db, currentSettings = {}) {
  const openingBalance = currentSettings.openingBalance || 0;
  const trackingStartDate = currentSettings.trackingStartDate || '';
  const theme = currentSettings.theme || 'light';
  
  return `
    <div class="card settings-form-card">
      <h2>Pengaturan</h2>
      <form id="settingsForm">
        <div class="form-group">
          <label>Saldo Awal</label>
          <input type="number" id="openingBalance" min="0" value="${openingBalance}" />
        </div>
        <div class="form-group">
          <label>Tanggal Mulai Pelacakan</label>
          <input type="date" id="trackingStartDate" value="${trackingStartDate}" />
        </div>
        <div class="form-group">
          <label>Tema</label>
          <select id="theme">
            <option value="light" ${theme === 'light' ? 'selected' : ''}>Terang</option>
            <option value="dark" ${theme === 'dark' ? 'selected' : ''}>Gelap</option>
          </select>
        </div>
        <button type="submit" class="btn primary">Simpan Pengaturan</button>
      </form>
    </div>
  `;
}