export function renderBudgetsForm(db) {
  return `
    <div class="card budget-form-card">
      <h2>Bulan Ini: ${new Date().toLocaleString('id-ID', { month: 'long' })}</h2>
      <form id="budgetForm">
        <div class="form-group">
          <label>Jumlah Anggaran</label>
          <input type="number" id="budgetLimit" min="0" required />
        </div>
        <div class="form-group">
          <label>Kategori</label>
          <select id="budgetCategory">
            <option value="">Overall (semua kategori)</option>
          </select>
        </div>
        <button type="submit" class="btn primary">Set Anggaran</button>
      </form>
    </div>
  `;
}

export function renderBudgetsOverview(db, month, theme) {
  return renderCategoryBudgets(db, month, theme);
}

export function renderBudgetForm(db) {
  return renderBudgetsForm(db);
}