export function renderHome(db, { openingBalance = 0, theme = 'light' } = {}) {
  return `
    <section class="dashboard">
      <div class="dashboard-stats">
        <div class="stat-card income-card">
          <h3>Total Masuk</h3>
          <p class="stat-value">Rp${formatIDR(0)}</p>
        </div>
        <div class="stat-card expense-card">
          <h3>Total Keluar</h3>
          <p class="stat-value">Rp${formatIDR(0)}</p>
        </div>
        <div class="stat-card balance-card">
          <h3>Sisa</h3>
          <p class="stat-value positive">Rp${formatIDR(0)}</p>
        </div>
      </div>
      <div class="budget-section">
        ${renderBudgetStatus(db, new Date().toISOString().slice(0, 7), theme)}
      </div>
      <div class="outings-summary">
        <h3>Aktivitas Terbaru</h3>
        <p class="muted">Belum ada aktivitas. Buat dari halaman Transaksi.</p>
      </div>
    </section>
  `;
}

export function renderBudgetOverview(db, month, theme) {
  return renderCategoryBudgets(db, month, theme);
}