export function renderTransactionsList(db, order = 'date-desc') {
  return `
    <div class="transactions-container">
      ${renderOutingsList(db)}
      <h3>Transaksi</h3>
      <div class="tx-list">
        <!-- Transactions will be rendered by transaction-service -->
      </div>
    </div>
  `;
}

export function renderTransactionForm(db, onSubmit) {
  const categories = await Promise.resolve([]); // Will be populated by caller
  return `
    <div class="card transaction-form-card">
      <h2>Transaksi Baru</h2>
      <form id="transactionForm">
        <div class="form-group">
          <label>Nama Transaksi</label>
          <input type="text" id="itemName" required />
        </div>
        <div class="form-group">
          <label>Jumlah</label>
          <input type="number" id="amount" min="0" required />
        </div>
        <div class="form-group">
          <label>Tipe</label>
          <select id="txType" onchange="toggleCategoryField()">
            <option value="expense">Pengeluaran</option>
            <option value="income">Masuk</option>
          </select>
        </div>
        <div class="form-group" id="categoryField">
          <label>Kategori</label>
          <select id="category">
            <option value="">Pilih kategori</option>
          </select>
        </div>
        <div class="form-group">
          <label>Kategori Khusus</label>
          <div id="customCategoryWrap" style="display:none">
            <input type="text" id="customCategory" placeholder="Nama kategori baru" />
          </div>
        </div>
        <div class="form-group">
          <label>Tanggal</label>
          <input type="date" id="date" />
        </div>
        <div class="form-group">
          <label>Keterangan</label>
          <textarea id="description"></textarea>
        </div>
        <button type="submit" class="btn primary">Simpan Transaksi</button>
      </form>
    </div>
  `;
}