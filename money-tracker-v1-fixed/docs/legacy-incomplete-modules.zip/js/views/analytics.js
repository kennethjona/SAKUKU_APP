export function renderInsights(db) {
  return `
    <div class="insights-panel">
      <h3>Wawasan Belanja</h3>
      <div id="insightsContainer">
        <!-- Insights rendered by analytics-service -->
      </div>
    </div>
  `;
}

export function renderMonthlyChart(db) {
  return `
    <div class="chart-panel">
      <h3>Aliran Bulanan</h3>
      <canvas id="monthlyChart"></canvas>
    </div>
  `;
}

export function renderCategoryChart(db) {
  return `
    <div class="chart-panel">
      <h3>Pengeluaran per Kategori</h3>
      <canvas id="categoryChart"></canvas>
    </div>
  `;
}