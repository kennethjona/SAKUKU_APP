export function renderOutingsList(db) {
  return `
    <div class="outings-section">
      <h3>Aktivitas Jalan-Jalan</h3>
      ${renderOutingsList(db)}
    </div>
  `;
}

export function renderOutingForm(db) {
  return `
    <div class="card outing-form-card">
      <h2>Aktivitas Baru</h2>
      <form id="outingForm">
        <div class="form-group">
          <label>Nama Aktivitas</label>
          <input type="text" id="outingName" required />
        </div>
        <div class="form-group">
          <label>Tanggal</label>
          <input type="date" id="outingDate" required />
        </div>
        <div class="form-group">
          <label>Anggaran</label>
          <input type="number" id="outingBudget" min="0" required />
        </div>
        <div class="form-group">
          <label>Catatan</label>
          <textarea id="outingNote"></textarea>
        </div>
        <button type="submit" class="btn primary">Buat Aktivitas</button>
      </form>
    </div>
  `;
}