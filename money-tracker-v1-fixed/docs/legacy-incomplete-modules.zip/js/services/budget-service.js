import {
  STORE_KEYS,
  TX_TYPES,
} from "../utils/defaults.js";
import {
  validateBudget,
  budgetStatus,
  formatIDR,
  formatPercent,
} from "../utils/validation.js";
import { formatIDR as fmtIDR } from "../utils/currency.js";
import { showToast } from "../services/transaction-service.js";

export async function loadBudgets(db) {
  const result = await getAllBudgets(db);
  return result.data || [];
}

export async function setMonthlyBudget(db, input) {
  const validation = await validateBudget(input);
  if (!validation.ok) {
    showToast(validation.errors.join(" "), "error");
    return { ok: false, errors: validation.errors };
  }

  const { month, categoryId, limitAmount } = validation.value;

  // Check for duplicate
  const budgets = await loadBudgets(db);
  const duplicate = budgets.some(
    (b) =>
      b.month === month &&
      b.categoryId === categoryId &&
      b.id !== `${month}:${categoryId}`,
  );

  if (duplicate) {
    showToast("Sudah ada anggaran untuk bulan/kategori ini", "error");
    return { ok: false, error: "Duplikat anggaran bulan/kategori" };
  }

  const result = await createBudget(db, {
    month,
    categoryId,
    limitAmount,
  });

  if (result.ok) {
    showToast(`Anggaran bulan ${fmtIDR(limitAmount)} diset`);
  } else {
    showToast("Gagal menyet anggaran", "error");
  }
  return result;
}

export async function removeBudget(db, month, categoryId = null) {
  const result = await deleteBudget(db, month, categoryId);
  if (result.ok) {
    showToast("Anggaran dihapus");
  } else {
    showToast("Gagal menghapus anggaran", "error");
  }
  return result;
}

export function renderBudgetStatus(db, month, theme) {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const mTotals = monthlyTotals(transactions, month);
    const settingsResult = await getSettings(db);
    const settings = settingsResult.data || { budgetLimit: 0 };

    const limit = Number(settings.budgetLimit) || 0;
    const spent = mTotals.expense;
    const { limit: l, spent: s, remaining, percent, state } = budgetStatus(
      limit,
      spent,
    );

    const colorMap = {
      safe: "var(--primary)",
      warning: "var(--warning)",
      critical: "var(--expense)",
      over: "var(--expense)",
    };

    const pctDisplay = percent !== null ? formatPercent(percent) : "—";

    return `
      <div class="budget-row">
        <div class="budget-row-head">
          <span class="budget-name">Anggaran Bulan Ini</span>
          <span class="budget-values">
            <strong>${fmtIDR(l)}</strong>
            <span>/${fmtIDR(l)}</span>
          </span>
        </div>
        <div class="budget-meta">
          <span>Total Belanja: ${fmtIDR(s)}</span>
          <span>Sisa: ${fmtIDR(remaining ?? 0)}</span>
        </div>
      </div>
      <div class="progress progress-lg">
        <div class="progress-fill ${state}" style="width:${percent ?? 0}%"></div>
      </div>
      <p class="faint">${pctDisplay} digunakan</p>`;
  });
}

export function renderCategoryBudgets(db, month, theme) {
  return getAllBudgets(db).then(({ data: budgets }) => {
    const mTotals = monthlyTotals(transactions => monthlyTotals(transactions, month));
    // Filter budgets for this month
    const monthBudgets = budgets.filter((b) => b.month === month);

    if (!monthBudgets.length) {
      return `<p class="muted">Belum ada anggaran bulanan untuk bulan ini.</p>`;
    }

    const rows = monthBudgets.map((b) => {
      const spent = monthlyExpenseTotal(transactions, month);
      const { remaining, percent, state } = budgetStatus(
        b.limitAmount,
        spent,
      );

      const color = state === "over" ? "var(--expense)" : state === "warning" ? "var(--warning)" : "var(--primary)";
      const pct = formatPercent(percent);

      return `
        <div class="budget-row">
          <div class="budget-row-head">
            <span class="budget-name">${b.categoryId ? `Kategori ${b.categoryId}` : "Overall"}</span>
            <span class="budget-values">
              <strong>${fmtIDR(b.limitAmount)}</strong>
              <span>/${fmtIDR(b.limitAmount)}</span>
            </span>
          </div>
          <div class="budget-meta">
            <span>Belanja: ${fmtIDR(spent)}</span>
            <span>Sisa: ${fmtIDR(remaining ?? 0)}</span>
          </div>
        </div>
        <div class="progress progress-lg">
          <div class="progress-fill ${state}" style="width:${percent ?? 0}%"></div>
        </div>
        <p class="faint">${pct} digunakan</p>`;
    }).join("");

    return `<div class="cat-budgets">${rows}</div>`;
  });
}