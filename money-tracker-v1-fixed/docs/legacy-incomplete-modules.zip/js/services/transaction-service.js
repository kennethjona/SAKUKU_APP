import {
  STORE_KEYS,
  TX_TYPES,
  PALETTE,
  makeDefaultCategories,
} from "../utils/defaults.js";
import {
  formatIDR,
  formatSignedIDR,
  formatCompactIDR,
  formatPercent,
} from "../utils/currency.js";
import {
  isValidDateString,
  isValidMonthString,
  parseDateLocal,
  formatDateID,
  formatMonthID,
  formatMonthShortID,
  elapsedDays,
  daysInMonth,
  monthRange,
  todayISO,
} from "../utils/dates.js";
import {
  totals,
  availableBalance,
  monthlyTotals,
  monthlyExpenseTotal,
  categoryTotals,
  budgetStatus,
  outingSpending,
  outingStatus,
  averageDailySpending,
  dailyExpenseSeries,
  monthlyFlowSeries,
  highestCategory,
  percentChange,
  compareMonths,
  detachOutingTransactions,
} from "../utils/finance.js";
import {
  validateTransaction,
  validateCategory,
  validateBudget,
  validateOuting,
  validateSettings,
} from "../utils/validation.js";

export async function loadInitialData(db) {
  // Load categories and settings; seed defaults if empty
  const catsResult = await getAllCategories(db);
  const settingsResult = await getSettings(db);

  let categories = catsResult.data || [];
  let settings = settingsResult.data || { ...DEFAULT_SETTINGS };

  if (!categories.length) {
    categories = makeDefaultCategories();
    await Promise.all(categories.map((cat) => createCategory(db, cat)));
  }

  if (!settings.openingBalance) {
    settings = { ...settings, openingBalance: 0 };
    await setSetting(db, "openingBalance", 0);
  }
  if (!settings.trackingStartDate) {
    settings = { ...settings, trackingStartDate: "" };
    await setSetting(db, "trackingStartDate", "");
  }
  if (!settings.theme) {
    settings = { ...settings, theme: "light" };
    await setSetting(db, "theme", "light");
  }

  return { categories, settings };
}

/** Render the balance card */
export function renderBalanceCard(db, { openingBalance, theme }) {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const bal = availableBalance(transactions, openingBalance);
    const income = sumAmounts(transactions, "income");
    const expense = sumAmounts(transactions, "expense");

    const themeEl = document.querySelector(`[data-theme="${theme}"]`);
    const balanceEl = document.createElement("div");
    balanceEl.className = `balance-card${theme ? "" : " is-light"}`;
    balanceEl.innerHTML = `
      <div class="balance-top">
        <p class="balance-label">TOTAL BALANCE</p>
        <p class="balance-amount ${bal < 0 ? "is-negative" : ""}" id="totalBalance">
          ${formatIDR(bal)}
        </p>
      </div>
      <div class="balance-foot">
        <div>
          <p class="balance-scope">Total Income: ${formatIDR(income)}</p>
          <p class="balance-scope">Total Expense: ${formatIDR(expense)}</p>
        </div>
        <div>
          <strong>${formatIDR(bal)}</strong>
        </div>
      </div>
    `;
    return balanceEl;
  });
}

/** Render monthly summary table */
export function renderMonthlySummary(db, month, { openingBalance }) {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const mTotals = monthlyTotals(transactions, month);
    const { limit, spent, remaining, percent, state } = budgetStatus(
      settings.budgetLimit ?? 0,
      mTotals.expense,
    );

    const catData = categoryTotals(transactions, month, "expense");

    const rows = catData.map((c) => {
      const cat = categories.find((c) => c.id === c.categoryId);
      const color = cat ? cat.color : "#aaaaaa";
      return `<tr>
        <td>
          <span style="display:inline-flex;align-items:center;gap:6px;">
            <span style="width:10px;height:10px;border-radius:50%;background:${color};display:inline-block;"></span>
            ${cat ? cat.name : "—"}
          </span>
        </td>
        <td class="col-income">${mTotals.income > 0 ? formatIDR(mTotals.income) : "—"}</td>
        <td class="col-expense">${formatIDR(c.amount)}</td>
        <td class="col-net ${c.amount >= 0 ? "positive" : "negative"}">${formatIDR(c.amount)}</td>
      </tr>`;
    }).join("");

    const netTotal = mTotals.income - mTotals.expense;

    return `
      <table class="summary-table" role="table">
        <thead>
          <tr>
            <th>Category</th><th>Income</th><th>Expense</th><th>Net</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="summary-totals">
        <div class="summary-total-item income">
          <div class="stl">Total Income</div>
          <div class="stv">${formatIDR(mTotals.income)}</div>
        </div>
        <div class="summary-total-item expense">
          <div class="stl">Total Expense</div>
          <div class="stv">${formatIDR(mTotals.expense)}</div>
        </div>
        <div class="summary-total-item net">
          <div class="stl">Net</div>
          <div class="stv" style="color:${netTotal >= 0 ? "var(--income-color)" : "var(--expense-color)"}">
            ${formatIDR(netTotal)}
          </div>
        </div>
      </div>`;
  });
}

/** Render spending pie chart */
export function renderChart(db, { theme }) {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const canvas = document.getElementById("spendingChart");
    const ctx = canvas.getContext("2d");
    const legend = document.getElementById("chartLegend");
    const empty = document.getElementById("emptyChart");

    const data = {};
    transactions
      .filter((t) => t.type === "expense")
      .forEach((t) => {
        data[t.categoryId] = (data[t.categoryId] || 0) + t.amount;
      });

    const entries = Object.entries(data).filter(([, v]) => v > 0);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    legend.innerHTML = "";

    if (!entries.length) {
      empty.classList.remove("hidden");
      canvas.style.display = "none";
      return;
    }

    empty.classList.add("hidden");
    canvas.style.display = "";

    const total = entries.reduce((s, [, v]) => s + v, 0);
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const radius = Math.min(cx, cy) - 8;
    let startAngle = -Math.PI / 2;

    entries.forEach(([catId, val]) => {
      const slice = (val / total) * 2 * Math.PI;
      const color = PALETTE[Number(catId) % PALETTE.length] || "#aaaaaa";

      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, startAngle, startAngle + slice);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();

      startAngle += slice;

      const item = document.createElement("div");
      item.className = "legend-item";
      item.innerHTML = `
        <span class="legend-dot" style="background:${color}"></span>
        <span>${catId} (${((val / total) * 100).toFixed(1)}%)</span>`;
      legend.appendChild(item);
    });
  });
}

/** Render transaction list */
export function renderTransactions(db, sortBy = "date-desc") {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const sorted = [...transactions].sort((a, b) => {
      if (sortBy === "date-asc") return new Date(a.date) - new Date(b.date);
      if (sortBy === "amount-desc") return b.amount - a.amount;
      if (sortBy === "amount-asc") return a.amount - b.amount;
      if (sortBy === "category") return a.category.localeCompare(b.category);
      return new Date(b.date) - new Date(a.date);
    });

    const list = document.getElementById("transactionList");
    if (!sorted.length) {
      list.innerHTML = '<li class="empty-state">No transactions yet. Add one above!</li>';
      return;
    }

    list.innerHTML = "";
    sorted.forEach((tx) => {
      const li = document.createElement("li");
      li.className = "tx-item";

      const color = "#64748b"; // default
      const cat = categories.find((c) => c.id === tx.categoryId);
      if (cat) color = cat.color;

      const sign = tx.type === "income" ? "+" : "-";
      const dateStr = formatDateID(tx.date);

      li.innerHTML = `
        <div class="tx-info">
          <p class="tx-name">${tx.name}</p>
          <p class="tx-amount ${tx.type}">${sign}${formatIDR(tx.amount)}</p>
          <div class="tx-meta">
            <span class="tx-badge" style="border-left:3px solid ${color}">
              ${tx.category}
            </span>
            <span class="tx-date">${dateStr}</span>
          </div>
        </div>
        <button class="btn btn-danger" aria-label="Delete ${tx.name}">Hapus</button>`;

      li.querySelector(".btn-danger").addEventListener("click", () =>
        deleteTransactionHandler(db, tx.id),
      );
      list.appendChild(li);
    });
  });
}

/** Show a toast notification */
export function showToast(message, type = "info") {
  const root = document.getElementById("toastRoot");
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
      ${type === "error"
        ? '<path d="M21 15a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h11l5 5v6a2 2 0 0 1-2 2z" />'
        : type === "warning"
          ? '<path d="M12 9v3m0 0v3m0-3h3m-3 0h3m-3-3v3m0 0v3m-3 0H9"/>' : ""}
    </svg>
    <span>${message}</span>`;
  root.appendChild(toast);

  // Auto-remove after 3 seconds
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s";
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

async function sumAmounts(transactions, type) {
  return transactions
    .filter((t) => t.type === type)
    .reduce((total, t) => total + t.amount, 0);
}

async function deleteTransactionHandler(db, id) {
  // Remove outing linkage first, then delete
  await deleteTransaction(db, id);
  showToast("Transaksi dihapus");
}