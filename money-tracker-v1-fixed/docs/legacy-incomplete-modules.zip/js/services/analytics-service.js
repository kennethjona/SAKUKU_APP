import {
  STORE_KEYS,
  TX_TYPES,
} from "../utils/defaults.js";
import {
  formatIDR,
  formatCompactIDR,
  formatPercent,
} from "../utils/currency.js";
import {
  isValidMonthString,
  monthOf,
  previousMonth,
  elapsedDays,
  daysInMonth,
  formatMonthID,
  formatMonthShortID,
  dailyExpenseSeries,
  monthlyFlowSeries,
  highestCategory,
  averageDailySpending,
  compareMonths,
  percentChange,
} from "../utils/finance.js";
import { getAllTransactions } from "../db/indexed-db.js";
import { showToast } from "../services/transaction-service.js";

export function renderInsights(db) {
  return getAllTransactions(db).then(({ data: transactions }) => {
    const today = new Date().toISOString().slice(0, 10);
    const settingsResult = db && (await dbTransaction(db, "settings"));
    // Get settings from local if available, otherwise defaults
    const openingBalance = 0; // Will be passed from UI

    const total = {
      income: sumAmounts(transactions, "income"),
      expense: sumAmounts(transactions, "expense"),
      balance: availableBalance(transactions, openingBalance),
    };

    // Monthly series - last 3 months
    const currentMonth = monthOf(today);
    const months = monthRange(currentMonth, 3);
    const series = monthlyFlowSeries(transactions, months);

    // Highest spending category
    const highest = highestCategory(transactions, currentMonth);

    // Average daily spending for current month
    const avgDaily = averageDailySpending(transactions, currentMonth);

    // Comparison with previous month
    const comparison = compareMonths(transactions, currentMonth);

    // Spending insights
    const insights = [];

    if (total.expense > 0) {
      if (avgDaily.average > 0) {
        insights.push({
          type: "info",
          icon: "💡",
          title: "Rata-rata Harian",
          message: `Anda membelanjakan rata-rata Rp${formatIDR(avgDaily.average)} per hari${avgDaily.isFuture ? " (bulan depan)" : ""}`,
        });
      }

      if (comparison.expenseChangePercent !== null) {
        const change = comparison.expenseChangePercent;
        const direction = change > 0 ? "naik" : "turun";
        insights.push({
          type: change > 0 ? "warning" : "positive",
          icon: change > 0 ? "📈" : "📉",
          title: `Perbandingan Bulan Lalu`,
          message: `Belanja ${direction} ${Math.abs(change).toFixed(1)}% dari bulan lalu`,
        });
      }

      if (highest) {
        insights.push({
          type: "danger",
          icon: "🔴",
          title: "Kategori Pengeluaran Tinggi",
          message: `Kategori paling besar: ${highest.categoryId || "—"}`,
        });
      }
    }

    return { total, series, highest, avgDaily, comparison, insights };
  });
}

function sumAmounts(transactions, type) {
  return transactions
    .filter((t) => t.type === type)
    .reduce((total, t) => total + t.amount, 0);
}