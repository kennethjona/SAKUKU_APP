import {
  STORE_KEYS,
  OUTING_STATUS,
} from "../utils/defaults.js";
import {
  validateOuting,
  createOuting,
  getAllOutings,
  updateOuting,
  deleteOuting,
} from "../db/indexed-db.js";
import {
  formatIDR,
  formatPercent,
} from "../utils/currency.js";
import { showToast } from "../services/transaction-service.js";
import { outingSpending, outingStatus } from "../utils/finance.js";

export async function loadOutings(db) {
  const result = await getAllOutings(db);
  return result.data || [];
}

export async function addOuting(db, input) {
  const validation = await validateOuting(input);
  if (!validation.ok) {
    showToast(validation.errors.join(" "), "error");
    return { ok: false, errors: validation.errors };
  }

  const { name, date, plannedBudget, note, status } = validation.value;

  const result = await createOuting(db, {
    id: `outing_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    name,
    date,
    plannedBudget,
    note,
    status,
  });

  if (result.ok) {
    showToast(`Aktivitas "${name}" ditambahkan`);
  } else {
    showToast("Gagal menambah aktivitas", "error");
  }
  return result;
}

export async function removeOuting(db, id) {
  // First detach transactions from the outing
  await deleteOuting(db, id);
  showToast("Aktivitas dihapus, transaksinya terlepas");
  return { ok: true };
}

export function renderOutingsList(db) {
  return getAllOutings(db).then(({ data: outings }) => {
    if (!outings.length) {
      return `<p class="muted">Belum ada aktivitas. Buat aktivitas baru dari halaman Transaksi.</p>`;
    }

    const rows = outings.map((outing) => {
      const spent = outingSpending(transactions => outingSpending(transactions, outing.id), []);
      // We need transactions; this will be resolved when rendering
      return `<div class="outing-card">
        <div class="outing-head">
          <div class="outing-icon" style="background:${outing.color || "#0f8a5f"};color:${outing.color || "#0f8a5f"};">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" /></svg>
          </div>
          <div>
            <h2>${outing.name}</h2>
            <p>${outing.note || ""}</p>
          </div>
          <button class="btn btn-danger btn-sm" onclick="removeOuting('${outing.id}')">Hapus</button>
        </div>
        <div class="outing-stats">
          <div class="outing-stat">
            <span>Anggaran</span>
            <strong>${formatIDR(outing.plannedBudget)}</strong>
          </div>
          <div class="outing-stat">
            <span>Total Belanja</span>
            <strong id="outing-spent-${outing.id}">Rp0</strong>
          </div>
          <div class="outing-stat">
            <span>Sisa</span>
            <strong id="outing-remaining-${outing.id}">Rp${outing.plannedBudget}</strong>
          </div>
        </div>
        <div class="outing-transactions" id="outing-tx-${outing.id}">
          <!-- Transactions will be rendered here -->
        </div>
        <div class="outing-actions">
          <button class="btn btn-secondary btn-sm" onclick="toggleOuting('${outing.id}')">Lengkapi</button>
        </div>
      </div>`;
    }).join("");

    return `<div class="outing-grid">${rows}</div>`;
  });
}

export function renderOutingDetail(db, outingId) {
  return getOuting(db, outingId).then(({ data: outing }) => {
    return getAllTransactions(db).then(({ data: transactions }) => {
      const spent = outingSpending(transactions, outingId);
      const { limit, spent: s, remaining, percent, state } = outingStatus(outing, transactions);

      const themeEl = document.querySelector(`[data-theme="dark"]`);
      const isDark = themeEl !== null;

      const colorMap = {
        safe: isDark ? "#4cc9ab" : "#0f8a5f",
        warning: isDark ? "#f0b45b" : "#a85a08",
        critical: isDark ? "#ff9a94" : "#cc4a54",
        over: isDark ? "#ff9a94" : "#cc4a54",
      };

      return `
        <div class="outing-card">
          <div class="outing-head">
            <div class="outing-icon" style="background:${colorMap[state] || "#0f8a5f"};color:${colorMap[state] || "#0f8a5f"};">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" /></svg>
            </div>
            <div>
              <h2>${outing.name}</h2>
              <p>${outing.note || ""}</p>
            </div>
            <button class="btn btn-danger btn-sm" onclick="removeOuting('${outingId}')">Hapus</button>
          </div>

          <div class="outing-stats">
            <div class="outing-stat">
              <span>Anggaran</span>
              <strong>${formatIDR(outing.plannedBudget)}</strong>
            </div>
            <div class="outing-stat">
              <span>Total Belanja</span>
              <strong>${formatIDR(spent)}</strong>
            </div>
            <div class="outing-stat">
              <span>Sisa</span>
              <strong>${formatIDR(remaining ?? 0)}</strong>
            </div>
          </div>

          <div class="progress progress-lg">
            <div class="progress-fill ${state}" style="width:${percent ?? 0}%"></div>
          </div>

          <p class="faint">${formatPercent(percent)} digunakan</p>

          <div class="outing-transactions" id="outing-tx-${outingId}">
            ${renderOutingTransactions(transactions, outingId)}
          </div>

          <div class="outing-actions">
            <button class="btn btn-${state === "over" ? "danger" : state === "warning" ? "warning" : "primary"} btn-sm">
              ${state === "over" ? "Over Budget" : state === "warning" ? "Peringatan" : "Aktif"}
            </button>
          </div>
        </div>`;
    });
  });
}

function renderOutingTransactions(transactions, outingId) {
  const linked = transactions.filter((t) => t.outingId === outingId);

  if (!linked.length) {
    return `<p class="muted">Belum ada transaksi dalam aktivitas ini.</p>`;
  }

  return `
    <ul class="outing-tx-list">
      ${linked.map((tx) => `
        <li class="tx-row">
          <span class="tx-name">${tx.name}</span>
          <span class="tx-amount expense">${formatIDR(tx.amount)}</span>
        </li>`).join("")}
    </ul>`;
}