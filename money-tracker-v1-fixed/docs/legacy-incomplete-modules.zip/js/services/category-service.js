import {
  STORE_KEYS,
  TX_TYPES,
  PALETTE,
  CATEGORY_NAME_MAX,
} from "../utils/defaults.js";
import {
  validateCategory,
  createCategory,
  getAllCategories,
  updateCategory,
  deleteCategory,
} from "../db/indexed-db.js";
import { formatIDR, formatCompactIDR } from "../utils/currency.js";
import { showToast } from "../services/transaction-service.js";

const colorIndexCache = new Map();

export async function loadCategories(db) {
  const result = await getAllCategories(db);
  return result.data || [];
}

export async function addCategory(db, input) {
  const validation = await validateCategory(input);
  if (!validation.ok) {
    showToast(validation.errors.join(" "), "error");
    return { ok: false, errors: validation.errors };
  }

  const now = new Date().toISOString();
  const record = {
    id: `cat_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    name: validation.value.name,
    type: validation.value.type,
    color: validation.value.color,
    archived: Boolean(validation.value.archived),
    createdAt: now,
    updatedAt: now,
  };

  const result = await createCategory(db, record);
  if (result.ok) {
    showToast(`Kategori "${validation.value.name}" ditambahkan`);
  } else {
    showToast("Gagal menambah kategori", "error");
  }
  return result;
}

export async function removeCategory(db, id) {
  const result = await deleteCategory(db, id);
  if (result.ok) {
    showToast("Kategori dihapus");
  } else {
    showToast(result.error || "Gagal menghapus kategori", "error");
  }
  return result;
}

export async function updateCategoryName(db, id, newName) {
  const validation = await validateCategory(
    { name: newName },
    { existing: { id } },
  );
  if (!validation.ok) {
    showToast(validation.errors.join(" "), "error");
    return { ok: false, errors: validation.errors };
  }

  const result = await updateCategory(db, id, {
    name: validation.value.name,
  });
  if (result.ok) {
    showToast("Nama kategori diperbarui");
  } else {
    showToast("Gagal memperbarui nama kategori", "error");
  }
  return result;
}

export function getCategoryColor(catId, categories) {
  const cat = categories.find((c) => c.id === catId);
  return cat ? cat.color : "#64748b";
}

export function getCategoryName(catId, categories) {
  const cat = categories.find((c) => c.id === catId);
  return cat ? cat.name : "—";
}

export function getCategoryType(catId, categories) {
  const cat = categories.find((c) => c.id === catId);
  return cat ? cat.type : "expense";
}

export function isCategoryArchived(catId, categories) {
  const cat = categories.find((c) => c.id === catId);
  return cat ? cat.archived : false;
}

export function generateColorIndex(categories) {
  // Simple deterministic color assignment
  let idx = 0;
  return function () {
    const result = PALETTE[idx % PALETTE.length];
    idx++;
    return result;
  };
}